"""Periodic online LoRA update coordination for the v1 runtime."""

from __future__ import annotations

from concurrent.futures import Future, ThreadPoolExecutor
from copy import deepcopy
from dataclasses import dataclass
import json
from math import ceil
from pathlib import Path
from statistics import mean
import time
from typing import Any, Mapping, Sequence
from urllib.request import Request, urlopen

from face_of_agi.contracts import (
    ActionSpec,
    Observation,
    ReplaySampleRecord,
    WorldPrediction,
)
from face_of_agi.environment.config import OnlineLoRAConfig
from face_of_agi.frames import from_memory_jsonable
from face_of_agi.memory import StateMemory
from face_of_agi.models.reward_judge.contracts import RewardJudgeInput, RewardJudgeModel

TRAINABLE_ROLES = ("world", "interest", "agent")


@dataclass(frozen=True, slots=True)
class LoRAReloadTarget:
    """vLLM adapter reload target."""

    role: str
    update_index: int
    adapter_name: str
    adapter_path: str
    sample_ids: tuple[int, ...]
    eval_sample_ids: tuple[int, ...]
    max_replay_sample_id: int
    sample_count: int


@dataclass(frozen=True, slots=True)
class ReplaySampleBatch:
    """Train/eval split for one online update attempt."""

    train_samples: tuple[ReplaySampleRecord, ...]
    eval_samples: tuple[ReplaySampleRecord, ...]


@dataclass(frozen=True, slots=True)
class CompletedLoRARole:
    """One vLLM-loaded role adapter ready for local activation."""

    target: LoRAReloadTarget
    metadata: dict[str, Any]


@dataclass(frozen=True, slots=True)
class CompletedLoRAUpdate:
    """Background result after the staged LoRA job finishes."""

    update_index: int
    completed_roles: tuple[CompletedLoRARole, ...] = ()


@dataclass(frozen=True, slots=True)
class HeldoutScore:
    """One World heldout prediction and Reward Judge score."""

    sample_id: int
    prediction: str
    score: float
    notes: str = ""
    error_tags: tuple[str, ...] = ()
    invalid_prediction: bool = False


class OnlineLoRACoordinator:
    """Schedule bounded async GRPO LoRA updates and vLLM adapter reloads."""

    def __init__(
        self,
        *,
        config: OnlineLoRAConfig,
        state_memory: StateMemory | None,
        vllm_base_url: str,
        run_id: str,
        game_id: str,
        reward_judge_model: RewardJudgeModel | None = None,
        activation_targets: Mapping[str, Any] | None = None,
    ) -> None:
        self.config = config
        self.state_memory = state_memory
        self.vllm_base_url = vllm_base_url.rstrip("/")
        self.run_id = run_id
        self.game_id = game_id
        self.reward_judge_model = reward_judge_model
        self._executor = ThreadPoolExecutor(max_workers=1)
        self._future: Future[CompletedLoRAUpdate] | None = None
        self._update_index = 0
        self._activation_targets = dict(activation_targets or {})
        self._last_trained_sample_id = {role: 0 for role in TRAINABLE_ROLES}

    def poll(self) -> None:
        """Apply completed async update work without doing trainer or vLLM I/O."""

        if self._future is None or not self._future.done():
            return
        future = self._future
        self._future = None
        self._apply_completed_update(future.result())

    def maybe_schedule(self, *, real_turn_count: int) -> None:
        """Schedule an update once every trainable role has a new micro-batch."""

        if not self.config.enabled or self.state_memory is None:
            return
        self.poll()
        if self._future is not None:
            return
        if real_turn_count <= 0:
            return

        samples_by_role = self._ready_samples_by_role()
        if samples_by_role is None:
            return

        self._update_index += 1
        for role, adapter_name in self._role_adapter_names().items():
            adapter_path = self._adapter_path(role)
            self._write_update(
                role=role,
                status="queued",
                adapter_name=adapter_name,
                adapter_path=str(adapter_path),
                metadata=self._batch_metadata(samples_by_role[role]),
            )
        self._future = self._executor.submit(
            self._run_update,
            self._update_index,
            samples_by_role,
        )

    def shutdown(self) -> None:
        """Wait for in-flight update work before process exit."""

        try:
            if self._future is not None:
                future = self._future
                self._future = None
                self._apply_completed_update(future.result())
        finally:
            self._executor.shutdown(wait=True)

    def _run_update(
        self,
        update_index: int,
        samples_by_role: Mapping[str, ReplaySampleBatch],
    ) -> CompletedLoRAUpdate:
        """Run the full staged trainer/reload pipeline off the game-loop thread."""

        completed: list[CompletedLoRARole] = []
        world_batch = samples_by_role["world"]
        interest_batch = samples_by_role["interest"]
        agent_batch = samples_by_role["agent"]
        world_adapter_name = self.config.world_adapter_name
        world_adapter_path = self._adapter_path("world", update_index=update_index)
        interest_adapter_name = self.config.interest_adapter_name
        interest_adapter_path = str(
            self._adapter_path("interest", update_index=update_index)
        )
        agent_adapter_name = self.config.agent_adapter_name
        agent_adapter_path = str(
            self._adapter_path("agent", update_index=update_index)
        )

        self._write_update(
            role="world",
            status="running",
            adapter_name=world_adapter_name,
            adapter_path=str(world_adapter_path),
            metadata=self._batch_metadata(world_batch),
        )
        try:
            _train_grpo_adapter(
                role="world",
                adapter_path=world_adapter_path,
                samples=world_batch.train_samples,
                config=self.config,
                reward_judge_model=self.reward_judge_model,
            )
        except Exception as exc:
            self._write_update(
                role="world",
                status="failed",
                adapter_name=world_adapter_name,
                adapter_path=str(world_adapter_path),
                error=str(exc),
                metadata=self._batch_metadata(world_batch),
            )
            self._write_role_skipped(
                "interest",
                interest_batch,
                adapter_name=interest_adapter_name,
                adapter_path=interest_adapter_path,
                error=f"skipped because World update failed: {exc}",
            )
            self._write_role_skipped(
                "agent",
                agent_batch,
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=f"skipped because World update failed: {exc}",
            )
            return CompletedLoRAUpdate(update_index=update_index)

        world_target = LoRAReloadTarget(
            role="world",
            update_index=update_index,
            adapter_name=world_adapter_name,
            adapter_path=str(world_adapter_path),
            sample_ids=tuple(sample.id for sample in world_batch.train_samples),
            eval_sample_ids=tuple(sample.id for sample in world_batch.eval_samples),
            max_replay_sample_id=max(sample.id for sample in world_batch.train_samples),
            sample_count=len(world_batch.train_samples),
        )
        try:
            lp_metadata = self._load_world_and_measure_learning_progress(
                world_target,
                eval_samples=world_batch.eval_samples,
            )
        except Exception as exc:
            self._write_update(
                role="world",
                status="failed",
                adapter_name=world_target.adapter_name,
                adapter_path=world_target.adapter_path,
                error=str(exc),
                metadata=self._target_metadata(world_target),
            )
            self._write_role_skipped(
                "interest",
                interest_batch,
                adapter_name=interest_adapter_name,
                adapter_path=interest_adapter_path,
                error=f"skipped because World LP evaluation failed: {exc}",
            )
            self._write_role_skipped(
                "agent",
                agent_batch,
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=f"skipped because World LP evaluation failed: {exc}",
            )
            return CompletedLoRAUpdate(update_index=update_index)

        completed.append(
            CompletedLoRARole(
                target=world_target,
                metadata={
                    **self._target_metadata(world_target),
                    **lp_metadata,
                },
            )
        )

        try:
            interest_samples = self._backfill_interest_labels(
                interest_batch,
                learning_progress=float(lp_metadata["learning_progress"]),
                learning_progress_metadata=lp_metadata,
                world_target=world_target,
            )
        except Exception as exc:
            self._write_update(
                role="interest",
                status="failed",
                adapter_name=interest_adapter_name,
                adapter_path=interest_adapter_path,
                error=str(exc),
                metadata=self._batch_metadata(interest_batch),
            )
            self._write_role_skipped(
                "agent",
                agent_batch,
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=f"skipped because Interest label backfill failed: {exc}",
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )

        self._write_update(
            role="interest",
            status="running",
            adapter_name=interest_adapter_name,
            adapter_path=interest_adapter_path,
            metadata={
                **self._batch_metadata(interest_batch),
                "learning_progress": lp_metadata["learning_progress"],
            },
        )
        try:
            _train_grpo_adapter(
                role="interest",
                adapter_path=Path(interest_adapter_path),
                samples=interest_samples,
                config=self.config,
                reward_judge_model=self.reward_judge_model,
            )
        except Exception as exc:
            self._write_update(
                role="interest",
                status="failed",
                adapter_name=interest_adapter_name,
                adapter_path=interest_adapter_path,
                error=str(exc),
                metadata={
                    **self._batch_metadata(interest_batch),
                    "learning_progress": lp_metadata["learning_progress"],
                },
            )
            self._write_role_skipped(
                "agent",
                agent_batch,
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=f"skipped because Interest update failed: {exc}",
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )

        interest_target = LoRAReloadTarget(
            role="interest",
            update_index=update_index,
            adapter_name=interest_adapter_name,
            adapter_path=interest_adapter_path,
            sample_ids=tuple(sample.id for sample in interest_samples),
            eval_sample_ids=tuple(sample.id for sample in interest_batch.eval_samples),
            max_replay_sample_id=max(sample.id for sample in interest_samples),
            sample_count=len(interest_samples),
        )
        try:
            self._load_lora_adapter(interest_target)
        except Exception as exc:
            self._write_update(
                role="interest",
                status="failed",
                adapter_name=interest_adapter_name,
                adapter_path=interest_adapter_path,
                error=str(exc),
                metadata=self._target_metadata(interest_target),
            )
            self._write_role_skipped(
                "agent",
                agent_batch,
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=f"skipped because Interest reload failed: {exc}",
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )
        completed.append(
            CompletedLoRARole(
                target=interest_target,
                metadata={
                    **self._target_metadata(interest_target),
                    "learning_progress": lp_metadata["learning_progress"],
                },
            )
        )

        try:
            agent_samples = self._backfill_agent_rewards(
                agent_batch,
                interest_samples=interest_samples,
                learning_progress=float(lp_metadata["learning_progress"]),
                learning_progress_metadata=lp_metadata,
                world_target=world_target,
                interest_target=interest_target,
            )
        except Exception as exc:
            self._write_update(
                role="agent",
                status="failed",
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=str(exc),
                metadata=self._batch_metadata(agent_batch),
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )

        self._write_update(
            role="agent",
            status="running",
            adapter_name=agent_adapter_name,
            adapter_path=agent_adapter_path,
            metadata={
                **self._batch_metadata(agent_batch),
                "learning_progress": lp_metadata["learning_progress"],
            },
        )
        try:
            _train_grpo_adapter(
                role="agent",
                adapter_path=Path(agent_adapter_path),
                samples=agent_samples,
                config=self.config,
                reward_judge_model=self.reward_judge_model,
            )
        except Exception as exc:
            self._write_update(
                role="agent",
                status="failed",
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=str(exc),
                metadata={
                    **self._batch_metadata(agent_batch),
                    "learning_progress": lp_metadata["learning_progress"],
                },
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )

        agent_target = LoRAReloadTarget(
            role="agent",
            update_index=update_index,
            adapter_name=agent_adapter_name,
            adapter_path=agent_adapter_path,
            sample_ids=tuple(sample.id for sample in agent_samples),
            eval_sample_ids=tuple(sample.id for sample in agent_batch.eval_samples),
            max_replay_sample_id=max(sample.id for sample in agent_samples),
            sample_count=len(agent_samples),
        )
        try:
            self._load_lora_adapter(agent_target)
        except Exception as exc:
            self._write_update(
                role="agent",
                status="failed",
                adapter_name=agent_adapter_name,
                adapter_path=agent_adapter_path,
                error=str(exc),
                metadata=self._target_metadata(agent_target),
            )
            return CompletedLoRAUpdate(
                update_index=update_index,
                completed_roles=tuple(completed),
            )
        completed.append(
            CompletedLoRARole(
                target=agent_target,
                metadata={
                    **self._target_metadata(agent_target),
                    "learning_progress": lp_metadata["learning_progress"],
                    "interest_adapter_name": interest_target.adapter_name,
                    "interest_trained_sample_ids": interest_target.sample_ids,
                },
            )
        )
        return CompletedLoRAUpdate(
            update_index=update_index,
            completed_roles=tuple(completed),
        )

    def _apply_completed_update(self, update: CompletedLoRAUpdate) -> None:
        """Activate loaded adapters locally and persist cheap success rows."""

        for index, completed in enumerate(update.completed_roles):
            target = completed.target
            metadata = dict(completed.metadata)
            try:
                self._activate_lora_adapter(target.role, target.adapter_name)
            except Exception as exc:
                error = f"local activation failed: {exc}"
                self._write_update(
                    role=target.role,
                    status="failed",
                    adapter_name=target.adapter_name,
                    adapter_path=target.adapter_path,
                    error=error,
                    metadata=metadata,
                )
                self._write_local_activation_skips(
                    update.completed_roles[index + 1 :],
                    failed_role=target.role,
                    error=error,
                )
                return
            self._last_trained_sample_id[target.role] = target.max_replay_sample_id
            metadata["local_activation_status"] = "activated"
            self._write_update(
                role=target.role,
                status="succeeded",
                adapter_name=target.adapter_name,
                adapter_path=target.adapter_path,
                metadata=metadata,
            )

    def _write_local_activation_skips(
        self,
        completed_roles: Sequence[CompletedLoRARole],
        *,
        failed_role: str,
        error: str,
    ) -> None:
        for completed in completed_roles:
            target = completed.target
            self._write_update(
                role=target.role,
                status="failed",
                adapter_name=target.adapter_name,
                adapter_path=target.adapter_path,
                error=f"skipped because {failed_role} {error}",
                metadata=dict(completed.metadata),
            )

    def _activate_lora_adapter(self, role: str, adapter_name: str) -> None:
        target = self._activation_targets.get(role)
        if target is None:
            raise RuntimeError(f"no LoRA activation target configured for {role}")
        activate = getattr(target, "activate_lora_adapter", None)
        if not callable(activate):
            raise RuntimeError(f"{role} model does not support LoRA activation")
        activate(adapter_name)

    def _load_lora_adapter(self, target: LoRAReloadTarget) -> None:
        """Ask vLLM to replace the stable role adapter in place."""

        payload = json.dumps(
            {
                "lora_name": target.adapter_name,
                "lora_path": target.adapter_path,
                "load_inplace": True,
            }
        ).encode("utf-8")
        request = Request(
            f"{self.vllm_base_url}/load_lora_adapter",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(request, timeout=60) as response:
            if response.status >= 400:
                raise RuntimeError(
                    f"vLLM LoRA reload failed for {target.adapter_name}: "
                    f"HTTP {response.status}"
            )

    def _load_world_and_measure_learning_progress(
        self,
        target: LoRAReloadTarget,
        *,
        eval_samples: Sequence[ReplaySampleRecord],
    ) -> dict[str, Any]:
        if not eval_samples:
            raise RuntimeError("World LP evaluation requires heldout samples")
        old_model = self._active_request_model("world")
        old_scores = self._score_world_eval_samples(
            eval_samples,
            model=old_model,
        )
        self._load_lora_adapter(target)
        new_scores = self._score_world_eval_samples(
            eval_samples,
            model=target.adapter_name,
        )
        old_by_id = {score.sample_id: score.score for score in old_scores}
        deltas = [
            score.score - old_by_id[score.sample_id]
            for score in new_scores
            if score.sample_id in old_by_id
        ]
        raw_learning_progress = mean(deltas) if deltas else 0.0
        learning_progress = _clip(
            raw_learning_progress,
            minimum=self.config.learning_progress_min,
            maximum=self.config.learning_progress_max,
        )
        return {
            "learning_progress": learning_progress,
            "raw_learning_progress": raw_learning_progress,
            "learning_progress_min": self.config.learning_progress_min,
            "learning_progress_max": self.config.learning_progress_max,
            "old_world_model": old_model,
            "new_world_model": target.adapter_name,
            "old_heldout_mean_score": mean(score.score for score in old_scores),
            "new_heldout_mean_score": mean(score.score for score in new_scores),
            "heldout_score_delta": deltas,
            "old_heldout_scores": [
                _heldout_score_metadata(score) for score in old_scores
            ],
            "new_heldout_scores": [
                _heldout_score_metadata(score) for score in new_scores
            ],
            "reload_status": "loaded_pending_local_activation",
        }

    def _score_world_eval_samples(
        self,
        samples: Sequence[ReplaySampleRecord],
        *,
        model: str,
    ) -> tuple[HeldoutScore, ...]:
        if self.reward_judge_model is None:
            raise RuntimeError("World LP evaluation requires Reward Judge")
        return tuple(
            self._score_world_eval_sample(sample, model=model)
            for sample in samples
        )

    def _score_world_eval_sample(
        self,
        sample: ReplaySampleRecord,
        *,
        model: str,
    ) -> HeldoutScore:
        prediction_text = self._predict_world_from_replay(sample, model=model)
        payload = _parse_completion_json(prediction_text)
        predicted_change = ""
        if payload is not None and isinstance(payload.get("predicted_change"), str):
            predicted_change = str(payload["predicted_change"]).strip()
        if not predicted_change:
            return HeldoutScore(
                sample_id=sample.id,
                prediction=prediction_text,
                score=0.0,
                notes="invalid World JSON prediction",
                invalid_prediction=True,
            )
        judge_input = self._world_judge_input(
            sample,
            model=model,
            predicted_change=predicted_change,
        )
        if self.reward_judge_model is None:
            raise RuntimeError("World LP evaluation requires Reward Judge")
        score = self.reward_judge_model.judge_prediction(judge_input)
        return HeldoutScore(
            sample_id=sample.id,
            prediction=predicted_change,
            score=score.score,
            notes=score.notes,
            error_tags=score.error_tags,
        )

    def _predict_world_from_replay(
        self,
        sample: ReplaySampleRecord,
        *,
        model: str,
    ) -> str:
        request_payload = deepcopy(_sample_request(sample))
        request_payload["model"] = model
        return _chat_completion_content(self.vllm_base_url, request_payload)

    def _world_judge_input(
        self,
        sample: ReplaySampleRecord,
        *,
        model: str,
        predicted_change: str,
    ) -> RewardJudgeInput:
        return _world_judge_input_from_bundle(
            bundle=_learning_progress_eval_bundle(sample),
            run_id=sample.run_id,
            game_id=sample.game_id,
            turn_id=sample.turn_id,
            sample_id=sample.id,
            model=model,
            predicted_change=predicted_change,
            reward_metadata={"learning_progress_eval": True},
        )

    def _backfill_interest_labels(
        self,
        batch: ReplaySampleBatch,
        *,
        learning_progress: float,
        learning_progress_metadata: Mapping[str, Any],
        world_target: LoRAReloadTarget,
    ) -> tuple[ReplaySampleRecord, ...]:
        state_memory = self._require_state_memory()
        updated: list[ReplaySampleRecord] = []
        for sample in batch.train_samples:
            label_components = sample.metadata.get("label_components")
            if not isinstance(label_components, dict):
                raise RuntimeError(
                    f"interest replay sample {sample.id} missing label_components"
                )
            executed_candidate_index = sample.metadata.get(
                "executed_candidate_index"
            )
            if isinstance(executed_candidate_index, bool) or not isinstance(
                executed_candidate_index,
                int,
            ):
                raise RuntimeError(
                    f"interest replay sample {sample.id} missing "
                    "executed_candidate_index"
                )
            goal_delta = _numeric_component(label_components, "goal_delta")
            metadata = dict(sample.metadata)
            metadata["interest_label"] = {
                "executed_candidate_index": executed_candidate_index,
                "realized_learning_progress": learning_progress,
                "realized_goal_delta": goal_delta,
                "label_source_update_index": world_target.update_index,
                "world_update_sample_ids": world_target.sample_ids,
                "world_eval_sample_ids": world_target.eval_sample_ids,
                "old_heldout_mean_score": learning_progress_metadata[
                    "old_heldout_mean_score"
                ],
                "new_heldout_mean_score": learning_progress_metadata[
                    "new_heldout_mean_score"
                ],
            }
            updated.append(
                state_memory.update_replay_sample_reward_metadata(
                    sample_id=sample.id,
                    reward=learning_progress,
                    metadata=metadata,
                )
            )
        return tuple(updated)

    def _backfill_agent_rewards(
        self,
        batch: ReplaySampleBatch,
        *,
        interest_samples: Sequence[ReplaySampleRecord],
        learning_progress: float,
        learning_progress_metadata: Mapping[str, Any],
        world_target: LoRAReloadTarget,
        interest_target: LoRAReloadTarget,
    ) -> tuple[ReplaySampleRecord, ...]:
        state_memory = self._require_state_memory()
        interest_by_turn = {sample.turn_id: sample for sample in interest_samples}
        updated: list[ReplaySampleRecord] = []
        for sample in batch.train_samples:
            components = sample.metadata.get("reward_components")
            if not isinstance(components, dict):
                raise RuntimeError(
                    f"agent replay sample {sample.id} missing reward_components"
                )
            lp_weight = _numeric_component(components, "lp_weight")
            goal_weight = _numeric_component(components, "goal_weight")
            goal_delta = _numeric_component(components, "goal_delta")
            progress_bonus = _numeric_component(components, "progress_bonus")
            reward = (
                lp_weight * learning_progress
                + goal_weight * goal_delta
                + progress_bonus
            )
            interest_sample = interest_by_turn.get(sample.turn_id)
            if interest_sample is None:
                raise RuntimeError(
                    f"agent replay sample {sample.id} missing paired Interest sample"
                )
            candidate_score_table = self._rescore_interest_sample(
                interest_sample,
                model=interest_target.adapter_name,
            )
            metadata = dict(sample.metadata)
            metadata["candidate_score_table"] = candidate_score_table
            metadata["candidate_score_table_source"] = {
                "interest_replay_sample_id": interest_sample.id,
                "interest_adapter_name": interest_target.adapter_name,
                "interest_adapter_sample_ids": interest_target.sample_ids,
            }
            metadata["learning_progress_backfill"] = {
                "learning_progress": learning_progress,
                "lp_weight": lp_weight,
                "goal_weight": goal_weight,
                "goal_delta": goal_delta,
                "progress_bonus": progress_bonus,
                "computed_reward": reward,
                "world_trained_sample_ids": world_target.sample_ids,
                "world_eval_sample_ids": world_target.eval_sample_ids,
                "interest_trained_sample_ids": interest_target.sample_ids,
                "old_heldout_mean_score": learning_progress_metadata[
                    "old_heldout_mean_score"
                ],
                "new_heldout_mean_score": learning_progress_metadata[
                    "new_heldout_mean_score"
                ],
            }
            updated.append(
                state_memory.update_replay_sample_reward_metadata(
                    sample_id=sample.id,
                    reward=reward,
                    metadata=metadata,
                )
            )
        return tuple(updated)

    def _rescore_interest_sample(
        self,
        sample: ReplaySampleRecord,
        *,
        model: str,
    ) -> tuple[dict[str, Any], ...]:
        prediction_text = self._predict_interest_from_replay(sample, model=model)
        payload = _parse_completion_json(prediction_text)
        if payload is None:
            raise RuntimeError(
                f"Interest replay sample {sample.id} produced invalid JSON"
            )
        return _candidate_score_table_from_interest_payload(sample, payload)

    def _predict_interest_from_replay(
        self,
        sample: ReplaySampleRecord,
        *,
        model: str,
    ) -> str:
        request_payload = deepcopy(_sample_request(sample))
        request_payload["model"] = model
        return _chat_completion_content(self.vllm_base_url, request_payload)

    def _write_role_skipped(
        self,
        role: str,
        batch: ReplaySampleBatch,
        *,
        adapter_name: str,
        adapter_path: str,
        error: str,
    ) -> None:
        self._write_update(
            role=role,
            status="failed",
            adapter_name=adapter_name,
            adapter_path=adapter_path,
            error=error,
            metadata=self._batch_metadata(batch),
        )

    def _active_request_model(self, role: str) -> str:
        target = self._activation_targets.get(role)
        active_name = _active_lora_adapter_name(target)
        if active_name:
            return active_name
        configured_model = _configured_model_name(target)
        if configured_model:
            return configured_model
        if self.config.base_model:
            return self.config.base_model
        raise RuntimeError(f"no active or base model configured for {role}")

    def _write_update(
        self,
        *,
        role: str,
        status: str,
        adapter_name: str,
        adapter_path: str,
        error: str = "",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        if self.state_memory is None:
            return
        update_metadata = {"timestamp": time.time()}
        update_metadata.update(metadata or {})
        self.state_memory.write_lora_update(
            run_id=self.run_id,
            game_id=self.game_id,
            update_index=self._update_index,
            role=role,
            status=status,
            adapter_name=adapter_name,
            adapter_path=adapter_path,
            error=error,
            metadata=update_metadata,
        )

    def _role_adapter_names(self) -> dict[str, str]:
        return {
            "world": self.config.world_adapter_name,
            "interest": self.config.interest_adapter_name,
            "agent": self.config.agent_adapter_name,
        }

    def _adapter_path(self, role: str, *, update_index: int | None = None) -> Path:
        if update_index is None:
            update_index = self._update_index
        return Path(self.config.adapter_root) / self.run_id / role / str(update_index)

    def _ready_samples_by_role(
        self,
    ) -> dict[str, ReplaySampleBatch] | None:
        state_memory = self._require_state_memory()
        threshold = self.config.min_new_samples_per_update
        if threshold is None:
            threshold = self.config.update_interval_turns
        reserve = self.config.held_out_recent_samples
        samples_by_role: dict[str, ReplaySampleBatch] = {}
        for role in TRAINABLE_ROLES:
            source_samples = tuple(
                state_memory.list_replay_samples(
                    run_id=self.run_id,
                    game_id=self.game_id,
                    role=role,
                    held_out=False,
                    after_id=self._last_trained_sample_id[role],
                    ascending=True,
                )
            )
            if len(source_samples) < threshold + reserve:
                return None
            eval_samples = source_samples[-reserve:]
            train_pool = source_samples[:-reserve]
            if len(train_pool) < threshold:
                return None
            train_samples = tuple(train_pool[: self.config.max_train_samples])
            if len(train_samples) < threshold:
                return None
            samples_by_role[role] = ReplaySampleBatch(
                train_samples=train_samples,
                eval_samples=tuple(eval_samples),
            )
        return samples_by_role

    def _batch_metadata(
        self,
        batch: ReplaySampleBatch,
    ) -> dict[str, Any]:
        sample_ids = tuple(int(sample.id) for sample in batch.train_samples)
        eval_sample_ids = tuple(int(sample.id) for sample in batch.eval_samples)
        return {
            "trained_sample_ids": sample_ids,
            "max_replay_sample_id": max(sample_ids) if sample_ids else 0,
            "sample_count": len(sample_ids),
            "eval_sample_ids": eval_sample_ids,
            "eval_sample_count": len(eval_sample_ids),
            "held_out_recent_samples": self.config.held_out_recent_samples,
            "rolling_reserve": True,
        }

    def _target_metadata(self, target: LoRAReloadTarget) -> dict[str, Any]:
        return {
            "update_index": target.update_index,
            "trained_sample_ids": target.sample_ids,
            "max_replay_sample_id": target.max_replay_sample_id,
            "sample_count": target.sample_count,
            "eval_sample_ids": target.eval_sample_ids,
            "eval_sample_count": len(target.eval_sample_ids),
            "held_out_recent_samples": self.config.held_out_recent_samples,
            "rolling_reserve": True,
        }

    def _require_state_memory(self) -> StateMemory:
        if self.state_memory is None:
            raise RuntimeError("online LoRA requires state memory")
        return self.state_memory


def _train_grpo_adapter(
    *,
    role: str,
    adapter_path: Path,
    samples: Sequence[ReplaySampleRecord],
    config: OnlineLoRAConfig,
    reward_judge_model: RewardJudgeModel | None = None,
) -> None:
    """Run a bounded TRL GRPO update for one role adapter."""

    if not samples:
        raise RuntimeError(f"no replay samples available for {role} LoRA update")
    if role == "world" and reward_judge_model is None:
        raise RuntimeError("World GRPO reward requires Reward Judge")

    try:
        from datasets import Dataset
        from peft import LoraConfig
        from trl import GRPOConfig, GRPOTrainer
    except ImportError as exc:
        raise RuntimeError(
            "online LoRA requires datasets, peft, and trl to be installed"
        ) from exc

    train_rows = [
        {
            "prompt": _sample_messages(sample),
            "target": _sample_target(sample),
            "recorded_reward": float(sample.reward),
            "role": sample.role,
            "metadata": sample.metadata,
            "run_id": sample.run_id,
            "game_id": sample.game_id,
            "turn_id": sample.turn_id,
            "sample_id": sample.id,
        }
        for sample in samples
    ]

    adapter_path.mkdir(parents=True, exist_ok=True)
    train_batch_size = min(config.train_batch_size, len(train_rows))
    training_args = GRPOConfig(
        output_dir=str(adapter_path),
        max_completion_length=config.max_completion_tokens,
        num_generations=max(2, config.grpo_num_generations),
        learning_rate=config.learning_rate,
        per_device_train_batch_size=train_batch_size,
        max_steps=_grpo_max_steps(sample_count=len(train_rows), config=config),
        logging_steps=1,
        save_steps=1,
    )
    base_model = str(samples[0].metadata.get("base_model") or config.base_model)
    if not base_model:
        raise RuntimeError("online LoRA requires online_lora.base_model")

    trainer = GRPOTrainer(
        model=base_model,
        reward_funcs=lambda completions, **kwargs: _reward_function(
            completions,
            reward_judge_model=reward_judge_model,
            **kwargs,
        ),
        args=training_args,
        train_dataset=Dataset.from_list(train_rows),
        peft_config=LoraConfig(
            r=8,
            lora_alpha=16,
            lora_dropout=0.05,
            task_type="CAUSAL_LM",
        ),
    )
    trainer.train()
    trainer.model.save_pretrained(str(adapter_path))


def _grpo_max_steps(*, sample_count: int, config: OnlineLoRAConfig) -> int:
    """Return enough GRPO steps to cover the selected replay rows."""

    train_batch_size = min(config.train_batch_size, sample_count)
    derived_steps = ceil(sample_count / train_batch_size) * config.train_epochs
    if config.max_update_steps is not None:
        return min(derived_steps, config.max_update_steps)
    return derived_steps


def _reward_function(
    completions: list[Any],
    *,
    reward_judge_model: RewardJudgeModel | None = None,
    **kwargs: Any,
) -> list[float]:
    """Reward generated JSON completions against replay targets."""

    roles = kwargs.get("role") or []
    metadata_items = kwargs.get("metadata") or []
    run_ids = kwargs.get("run_id") or []
    game_ids = kwargs.get("game_id") or []
    turn_ids = kwargs.get("turn_id") or []
    sample_ids = kwargs.get("sample_id") or []
    rewards: list[float] = []
    for index, completion in enumerate(completions):
        text = _completion_text(completion)
        role = str(roles[index]) if index < len(roles) else ""
        metadata = (
            metadata_items[index]
            if index < len(metadata_items) and isinstance(metadata_items[index], dict)
            else {}
        )
        if role == "agent":
            rewards.append(_agent_candidate_value_reward(text, metadata))
        elif role == "interest":
            rewards.append(_interest_label_reward(text, metadata))
        elif role == "world":
            rewards.append(
                _world_generated_output_reward(
                    completion_text=text,
                    metadata=metadata,
                    reward_judge_model=reward_judge_model,
                    run_id=str(run_ids[index]) if index < len(run_ids) else "",
                    game_id=str(game_ids[index]) if index < len(game_ids) else "",
                    turn_id=turn_ids[index] if index < len(turn_ids) else None,
                    sample_id=sample_ids[index] if index < len(sample_ids) else None,
                )
            )
        else:
            rewards.append(0.0)
    return rewards


def _world_generated_output_reward(
    *,
    completion_text: str,
    metadata: Mapping[str, Any],
    reward_judge_model: RewardJudgeModel | None,
    run_id: str,
    game_id: str,
    turn_id: Any,
    sample_id: Any,
) -> float:
    """Score the generated World output itself with Reward Judge."""

    payload = _parse_completion_json(completion_text)
    predicted_change = ""
    if payload is not None and isinstance(payload.get("predicted_change"), str):
        predicted_change = str(payload["predicted_change"]).strip()
    if not predicted_change:
        return 0.0
    if reward_judge_model is None:
        raise RuntimeError("World GRPO reward requires Reward Judge")
    judge_input = _world_judge_input_from_bundle(
        bundle=_learning_progress_eval_bundle_from_metadata(
            metadata,
            label=f"world replay sample {sample_id}",
        ),
        run_id=run_id,
        game_id=game_id,
        turn_id=_int_or_zero(turn_id),
        sample_id=_int_or_zero(sample_id),
        model="grpo_generated_world",
        predicted_change=predicted_change,
        reward_metadata={"generated_training_reward": True},
    )
    score = reward_judge_model.judge_prediction(judge_input)
    return score.score


def _sample_messages(sample: ReplaySampleRecord) -> list[dict[str, Any]]:
    request = _sample_request(sample)
    messages = request.get("messages")
    if not isinstance(messages, list) or not messages:
        raise RuntimeError(f"{sample.role} replay sample {sample.id} missing messages")
    return messages


def _sample_request(sample: ReplaySampleRecord) -> dict[str, Any]:
    request = sample.prompt_json.get("request")
    if not isinstance(request, dict):
        raise RuntimeError(f"{sample.role} replay sample {sample.id} missing request")
    return request


def _sample_target(sample: ReplaySampleRecord) -> dict[str, Any]:
    target = sample.completion_json.get("target")
    if not isinstance(target, dict):
        raise RuntimeError(f"{sample.role} replay sample {sample.id} missing target")
    return target


def _agent_candidate_value_reward(
    completion_text: str,
    metadata: Mapping[str, Any],
) -> float:
    invalid_reward = _invalid_agent_output_reward(metadata)
    completion = _parse_completion_json(completion_text)
    if completion is None:
        return invalid_reward
    generated_action = completion.get("action")
    if not isinstance(generated_action, dict):
        return invalid_reward
    table = _candidate_score_table(metadata)
    if not table:
        return invalid_reward
    normalized_table = _with_normalized_advantages(table)
    for item in normalized_table:
        action = item.get("model_action")
        if not isinstance(action, dict):
            action = item.get("action")
        if isinstance(action, dict) and _same_action_json(
            generated_action,
            action,
            action_name=str(item.get("action_name") or ""),
        ):
            return _numeric_or_zero(item.get("normalized_advantage"))
    return invalid_reward


def _invalid_agent_output_reward(metadata: Mapping[str, Any]) -> float:
    table = _candidate_score_table(metadata)
    if not table:
        return -1.0
    valid_rewards = [
        _numeric_or_zero(item.get("normalized_advantage"))
        for item in _with_normalized_advantages(table)
        if isinstance(item.get("model_action"), dict)
        or isinstance(item.get("action"), dict)
    ]
    if not valid_rewards:
        return -1.0
    return min(valid_rewards) - 1e-6


def _interest_label_reward(
    completion_text: str,
    metadata: Mapping[str, Any],
) -> float:
    label = metadata.get("interest_label")
    if not isinstance(label, dict):
        return 0.0
    completion = _parse_completion_json(completion_text)
    if completion is None:
        return 0.0
    values = completion.get("candidate_values")
    if not isinstance(values, list):
        return 0.0
    executed_index = label.get("executed_candidate_index")
    if isinstance(executed_index, bool) or not isinstance(executed_index, int):
        return 0.0
    target_lp = _numeric_or_none(label.get("realized_learning_progress"))
    target_goal_delta = _numeric_or_none(label.get("realized_goal_delta"))
    if target_lp is None or target_goal_delta is None:
        return 0.0
    for raw_value in values:
        if not isinstance(raw_value, dict):
            continue
        if raw_value.get("candidate_index") != executed_index:
            continue
        predicted_lp = _numeric_or_none(raw_value.get("expected_learning_progress"))
        predicted_goal_delta = _numeric_or_none(raw_value.get("expected_goal_delta"))
        confidence = _numeric_or_none(raw_value.get("confidence"))
        if (
            predicted_lp is None
            or predicted_goal_delta is None
            or confidence is None
        ):
            return 0.0
        value_error = min(
            1.0,
            (
                abs(predicted_lp - target_lp)
                + abs(predicted_goal_delta - target_goal_delta)
            )
            / 2.0,
        )
        value_reward = 1.0 - value_error
        confidence_target = value_reward
        calibration_reward = 1.0 - min(1.0, abs(confidence - confidence_target))
        return 0.8 * value_reward + 0.2 * calibration_reward
    return 0.0


def _parse_completion_json(text: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    return payload


def _completion_text(completion: Any) -> str:
    if isinstance(completion, str):
        return completion
    if isinstance(completion, list):
        parts = []
        for item in completion:
            if isinstance(item, dict):
                parts.append(str(item.get("content") or ""))
            else:
                parts.append(str(item))
        return "\n".join(parts)
    return str(completion)


def _chat_completion_content(vllm_base_url: str, request_payload: dict[str, Any]) -> str:
    payload = json.dumps(request_payload).encode("utf-8")
    request = Request(
        f"{vllm_base_url.rstrip('/')}/chat/completions",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=120) as response:
        if response.status >= 400:
            raise RuntimeError(f"vLLM chat completion failed: HTTP {response.status}")
        body = response.read().decode("utf-8")
    loaded = json.loads(body)
    choices = loaded.get("choices") if isinstance(loaded, dict) else None
    if not isinstance(choices, list) or not choices:
        raise RuntimeError("vLLM chat completion response missing choices")
    message = choices[0].get("message") if isinstance(choices[0], dict) else None
    if not isinstance(message, dict):
        raise RuntimeError("vLLM chat completion response missing message")
    content = message.get("content")
    if not isinstance(content, str):
        raise RuntimeError("vLLM chat completion response missing text content")
    return content


def _learning_progress_eval_bundle(sample: ReplaySampleRecord) -> dict[str, Any]:
    return _learning_progress_eval_bundle_from_metadata(
        sample.metadata,
        label=f"world replay sample {sample.id}",
    )


def _learning_progress_eval_bundle_from_metadata(
    metadata: Mapping[str, Any],
    *,
    label: str,
) -> dict[str, Any]:
    bundle = metadata.get("learning_progress_eval")
    if not isinstance(bundle, dict):
        raise RuntimeError(f"{label} missing learning_progress_eval")
    required = {
        "action",
        "change_summary",
        "previous_observation",
        "current_observation",
    }
    missing = sorted(required - set(bundle))
    if missing:
        names = ", ".join(missing)
        raise RuntimeError(f"{label} missing LP eval fields: {names}")
    return bundle


def _world_judge_input_from_bundle(
    *,
    bundle: Mapping[str, Any],
    run_id: str,
    game_id: str,
    turn_id: int,
    sample_id: int,
    model: str,
    predicted_change: str,
    reward_metadata: Mapping[str, Any],
) -> RewardJudgeInput:
    action = _action_from_json(bundle["action"])
    candidate_index = int(bundle.get("candidate_index") or 0)
    return RewardJudgeInput(
        run_id=run_id,
        game_id=game_id,
        turn_id=turn_id,
        action=action,
        prediction=WorldPrediction(
            candidate_index=candidate_index,
            action=action,
            predicted_change=predicted_change,
            metadata={
                "model": model,
                "replay_sample_id": sample_id,
                **dict(reward_metadata),
            },
        ),
        change_summary=str(bundle["change_summary"]),
        previous_observation=_observation_from_jsonable(
            bundle["previous_observation"]
        ),
        current_observation=_observation_from_jsonable(
            bundle["current_observation"]
        ),
        metadata={
            "replay_sample_id": sample_id,
            "model": model,
            **dict(reward_metadata),
        },
    )


def _candidate_score_table_from_interest_payload(
    sample: ReplaySampleRecord,
    payload: Mapping[str, Any],
) -> tuple[dict[str, Any], ...]:
    original_by_index = {
        int(item["candidate_index"]): item
        for item in _candidate_score_table(sample.metadata)
        if isinstance(item.get("candidate_index"), int)
    }
    values = payload.get("candidate_values")
    if not isinstance(values, list):
        raise RuntimeError(
            f"Interest replay sample {sample.id} missing candidate_values"
        )
    label_components = sample.metadata.get("label_components")
    if not isinstance(label_components, dict):
        raise RuntimeError(
            f"Interest replay sample {sample.id} missing label_components"
        )
    lp_weight = _numeric_component(label_components, "lp_weight")
    goal_weight = _numeric_component(label_components, "goal_weight")
    table: list[dict[str, Any]] = []
    returned_indices: set[int] = set()
    for raw_value in values:
        if not isinstance(raw_value, dict):
            raise RuntimeError(
                f"Interest replay sample {sample.id} candidate value is not an object"
            )
        candidate_index = raw_value.get("candidate_index")
        if isinstance(candidate_index, bool) or not isinstance(candidate_index, int):
            raise RuntimeError(
                f"Interest replay sample {sample.id} candidate_index must be integer"
            )
        original = original_by_index.get(candidate_index)
        if original is None:
            raise RuntimeError(
                f"Interest replay sample {sample.id} returned unknown "
                f"candidate_index {candidate_index}"
            )
        if candidate_index in returned_indices:
            raise RuntimeError(
                f"Interest replay sample {sample.id} duplicated "
                f"candidate_index {candidate_index}"
            )
        returned_indices.add(candidate_index)
        expected_lp = _bounded_numeric(
            raw_value.get("expected_learning_progress"),
            minimum=-1.0,
            maximum=1.0,
            label="expected_learning_progress",
        )
        expected_goal_delta = _bounded_numeric(
            raw_value.get("expected_goal_delta"),
            minimum=-1.0,
            maximum=1.0,
            label="expected_goal_delta",
        )
        confidence = _bounded_numeric(
            raw_value.get("confidence"),
            minimum=0.0,
            maximum=1.0,
            label="confidence",
        )
        confidence_adjusted_lp = confidence * expected_lp
        blended_score = lp_weight * confidence_adjusted_lp + goal_weight * (
            expected_goal_delta
        )
        table.append(
            {
                "candidate_index": candidate_index,
                "action": original["action"],
                "model_action": original.get("model_action", original["action"]),
                "action_name": original.get("action_name"),
                "expected_learning_progress": expected_lp,
                "confidence": confidence,
                "confidence_adjusted_learning_progress": confidence_adjusted_lp,
                "expected_goal_delta": expected_goal_delta,
                "blended_score": blended_score,
                "notes": str(raw_value.get("notes") or "").strip(),
                "metadata": {
                    "lp_weight": lp_weight,
                    "goal_weight": goal_weight,
                    "source": "interest_rescore",
                    "replay_sample_id": sample.id,
                },
            }
        )
    missing = sorted(set(original_by_index) - returned_indices)
    if missing:
        raise RuntimeError(
            f"Interest replay sample {sample.id} missing candidate indices: "
            + ", ".join(str(index) for index in missing)
        )
    return _with_normalized_advantages(tuple(table))


def _candidate_score_table(
    metadata: Mapping[str, Any],
) -> tuple[dict[str, Any], ...]:
    table = metadata.get("candidate_score_table")
    if not isinstance(table, (list, tuple)):
        return ()
    return tuple(item for item in table if isinstance(item, dict))


def _with_normalized_advantages(
    table: Sequence[Mapping[str, Any]],
) -> tuple[dict[str, Any], ...]:
    scores = [
        _numeric_or_none(item.get("blended_score"))
        for item in table
    ]
    if any(score is None for score in scores):
        return tuple(dict(item) for item in table)
    numeric_scores = [float(score) for score in scores if score is not None]
    mean_score = mean(numeric_scores) if numeric_scores else 0.0
    advantages = [score - mean_score for score in numeric_scores]
    max_abs_advantage = max((abs(value) for value in advantages), default=0.0)
    normalized: list[dict[str, Any]] = []
    for item, advantage in zip(table, advantages):
        copied = dict(item)
        copied["advantage"] = advantage
        copied["normalized_advantage"] = (
            0.0 if max_abs_advantage <= 1e-12 else advantage / max_abs_advantage
        )
        normalized.append(copied)
    return tuple(normalized)


def _action_from_json(value: Any) -> ActionSpec:
    if not isinstance(value, dict):
        raise RuntimeError("LP eval action must be a JSON object")
    if "action_id" not in value:
        raise RuntimeError("LP eval action missing action_id")
    data = value.get("data")
    if data is not None and not isinstance(data, dict):
        raise RuntimeError("LP eval action data must be an object or null")
    return ActionSpec(action_id=str(value["action_id"]), data=data)


def _observation_from_jsonable(value: Any) -> Observation:
    hydrated = from_memory_jsonable(value)
    if not isinstance(hydrated, dict):
        raise RuntimeError("LP eval observation must be a JSON object")
    metadata = hydrated.get("metadata") or {}
    if not isinstance(metadata, dict):
        raise RuntimeError("LP eval observation metadata must be an object")
    frames = hydrated.get("frames") or ()
    if not isinstance(frames, (list, tuple)):
        raise RuntimeError("LP eval observation frames must be a list")
    return Observation(
        id=str(hydrated.get("id") or ""),
        step=int(hydrated.get("step") or 0),
        frame=hydrated.get("frame"),
        frames=tuple(frames),
        raw_frame_data=hydrated.get("raw_frame_data"),
        metadata=metadata,
    )


def _numeric_component(components: Mapping[str, Any], key: str) -> float:
    value = components.get(key)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise RuntimeError(f"reward component {key} must be numeric")
    return float(value)


def _numeric_or_none(value: Any) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _numeric_or_zero(value: Any) -> float:
    numeric = _numeric_or_none(value)
    return 0.0 if numeric is None else numeric


def _int_or_zero(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        return 0
    return value


def _bounded_numeric(
    value: Any,
    *,
    minimum: float,
    maximum: float,
    label: str,
) -> float:
    from math import isfinite

    numeric = _numeric_or_none(value)
    if numeric is None or not isfinite(numeric) or not minimum <= numeric <= maximum:
        raise RuntimeError(f"{label} must be within {minimum}..{maximum}")
    return numeric


def _same_action_json(
    generated: Mapping[str, Any],
    candidate: Mapping[str, Any],
    *,
    action_name: str,
) -> bool:
    generated_name = _action_name_from_json(generated)
    candidate_name = action_name or _action_name_from_json(candidate)
    if generated_name != candidate_name:
        return False
    return _action_data_json(generated) == _action_data_json(candidate)


def _action_name_from_json(value: Mapping[str, Any]) -> str:
    raw = str(value.get("action_id") or value.get("name") or "")
    if "." in raw:
        raw = raw.rsplit(".", 1)[-1]
    return raw


def _action_data_json(value: Mapping[str, Any]) -> dict[str, Any]:
    data = value.get("data")
    return dict(data) if isinstance(data, dict) else {}


def _clip(value: float, *, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def _heldout_score_metadata(score: HeldoutScore) -> dict[str, Any]:
    return {
        "sample_id": score.sample_id,
        "prediction": score.prediction,
        "score": score.score,
        "notes": score.notes,
        "error_tags": score.error_tags,
        "invalid_prediction": score.invalid_prediction,
    }


def _active_lora_adapter_name(target: Any | None) -> str:
    for candidate in (target, getattr(target, "provider", None)):
        name = getattr(candidate, "active_lora_adapter_name", None)
        if name:
            return str(name)
    return ""


def _configured_model_name(target: Any | None) -> str:
    for candidate in (target, getattr(target, "provider", None)):
        config = getattr(candidate, "config", None)
        model = getattr(config, "model", None)
        if model:
            return str(model)
    return ""
