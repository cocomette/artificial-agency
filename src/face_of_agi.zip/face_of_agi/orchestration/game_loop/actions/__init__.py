"""Game-loop action implementations."""
