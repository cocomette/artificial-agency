"""vLLM adapter for the regenerated Memory role."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from face_of_agi.contracts import MemoryDocument, TurnLedgerEntry
from face_of_agi.frames import to_memory_jsonable
from face_of_agi.models.memory.config import VLLMMemoryConfig
from face_of_agi.models.memory.contracts import (
    MemoryBuildInput,
    memory_output_json_schema,
)
from face_of_agi.models.vllm_roles import (
    VLLMJsonRoleClient,
    observation_image,
    parse_json_object,
)

DEFAULT_INSTRUCTION_PATH = Path(__file__).parent / "instructions" / "instruction_prompt.md"


class VLLMMemoryAdapter:
    """Memory role backed by vLLM Chat Completions."""

    def __init__(
        self,
        config: VLLMMemoryConfig,
        *,
        client: Any | None = None,
    ) -> None:
        self.config = config
        self.provider = VLLMJsonRoleClient(
            config=config,
            call_slot="memory",
            instruction_path=DEFAULT_INSTRUCTION_PATH,
            client=client,
        )

    def build_memory(self, build_input: MemoryBuildInput) -> MemoryDocument:
        """Regenerate memory from first/current frames and the full ledger."""

        text = self.provider.complete_json(
            prompt_text=_memory_prompt(build_input),
            output_schema=memory_output_json_schema(),
            schema_name="memory_document",
            images=(
                observation_image(self.config, build_input.first_observation),
                observation_image(self.config, build_input.current_observation),
            ),
        )
        payload = parse_json_object(text, label="memory")
        document = str(payload.get("document") or "").strip()
        if not document:
            raise RuntimeError("memory response requires non-empty document")
        return MemoryDocument(
            document=document,
            metadata={
                "backend": "vllm",
                "model": self.config.model,
                "ledger_entry_count": len(build_input.ledger),
            },
        )


def _memory_prompt(build_input: MemoryBuildInput) -> str:
    """Return the Memory role prompt."""

    return "\n\n".join(
        [
            f"run_id: {build_input.run_id}",
            f"game_id: {build_input.game_id}",
            "Attached images: first frame, current frame.",
            "Full action/change/reward ledger JSON:",
            _json_text([_ledger_entry_json(entry) for entry in build_input.ledger]),
            "Regenerate the complete memory document from this full ledger. "
            "Do not rely on a previous memory document.",
        ]
    )


def _ledger_entry_json(entry: TurnLedgerEntry) -> dict[str, Any]:
    if is_dataclass(entry):
        return to_memory_jsonable(asdict(entry))
    return to_memory_jsonable(entry)


def _json_text(value: Any) -> str:
    import json

    return json.dumps(value, indent=2, sort_keys=True)
