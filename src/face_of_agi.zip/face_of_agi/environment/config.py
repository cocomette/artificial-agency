"""Environment-local configuration for the starter ARC shell."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any, Literal

import yaml
from arc_agi import OperationMode

DebugTraceMode = Literal[
    "off",
    "minimal",
    "agent_decision",
    "verbose",
    "model_inputs",
]
DebugColorMode = Literal["auto", "always", "never"]
GameSelectionMode = Literal["all_available"]


@dataclass(slots=True)
class ModelRoleConfig:
    """Runtime-selected model role backend configuration."""

    backend: str | None = None
    model: str | None = None
    max_tool_calls: int | None = None
    repair_attempts: int | None = None
    options: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class ModelRuntimeConfig:
    """Runtime model backend config for agent and tool roles."""

    shared_vlm: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    agent: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    change: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    memory: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    world: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    goal: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    interest: ModelRoleConfig = field(default_factory=ModelRoleConfig)
    reward_judge: ModelRoleConfig = field(default_factory=ModelRoleConfig)


@dataclass(slots=True)
class OnlineLoRAConfig:
    """Runtime config for periodic online LoRA updates."""

    enabled: bool = True
    base_model: str = ""
    update_interval_turns: int = 4
    min_new_samples_per_update: int | None = None
    adapter_root: str = "runs/lora"
    world_adapter_name: str = "world-lora"
    interest_adapter_name: str = "interest-lora"
    agent_adapter_name: str = "agent-lora"
    max_train_samples: int = 16
    held_out_recent_samples: int = 8
    train_batch_size: int = 1
    train_epochs: int = 1
    max_update_steps: int | None = None
    grpo_num_generations: int = 4
    max_completion_tokens: int = 512
    learning_rate: float = 1e-5
    learning_progress_min: float = -1.0
    learning_progress_max: float = 1.0


@dataclass(slots=True)
class EnvironmentConfig:
    """Minimal environment config for the starter runtime shell."""

    game_index: int | None = None
    max_actions_per_level: int = 0
    max_levels_per_game: int | None = None
    game_indices: tuple[int, ...] = ()
    game_ids: tuple[str, ...] = ()
    game_selection: GameSelectionMode | None = None
    max_parallel_games: int | None = None
    max_game_retries: int = 0
    game_id: str | None = None
    operation_mode: OperationMode = OperationMode.OFFLINE
    game_catalog_path: str = "src/face_of_agi/environment/local_games.json"
    environments_dir: str = "environment_files"
    recordings_dir: str = "recordings"
    enable_visualization: bool = False
    render_mode: str | None = None
    seed: int = 0
    save_recording: bool = False
    use_learned_contexts: bool = True
    experimental_memory_turn_buffer: int = 2
    agent_action_history_window: int = 8
    agent_updater_action_history_window: int = 8
    agent_context_history_window: int = 8
    animation_keyframe_pixel_threshold: int = 8
    action_suppression_zero_changed_pixel_turns: int = 3
    updater_stagnation_warning_zero_changed_pixel_turns: int = 3
    candidate_action_count: int = 8
    reward_lp_weight_start: float = 0.8
    reward_lp_weight_end: float = 0.2
    reward_progress_bonus: float = 1.0
    debug_keep_all_m_states: bool = False
    debug_trace: DebugTraceMode = "minimal"
    debug_color: DebugColorMode = "auto"
    live_turn_monitor: bool = False
    models: ModelRuntimeConfig = field(default_factory=ModelRuntimeConfig)
    online_lora: OnlineLoRAConfig = field(default_factory=OnlineLoRAConfig)


def load_environment_config(path: str | Path) -> EnvironmentConfig:
    """Load the starter environment config from YAML."""

    raw_data = _read_yaml(path)
    game_index, game_indices, game_ids, game_selection = _load_game_selection(raw_data)
    game_id = _optional_string(raw_data.get("game_id"))
    if (game_indices or game_ids or game_selection is not None) and game_id is not None:
        raise ValueError(
            "game_id cannot be set when game_indices, game_ids, or "
            "game_selection is configured"
        )
    max_actions_per_level = int(raw_data["max_actions_per_level"])
    operation_mode = OperationMode(str(raw_data.get("operation_mode", "offline")))
    models = _load_model_runtime_config(raw_data.get("models"))
    online_lora = _load_online_lora_config(raw_data.get("online_lora"))
    if not online_lora.base_model:
        online_lora.base_model = (
            models.shared_vlm.model
            or models.world.model
            or models.interest.model
            or models.agent.model
            or ""
        )

    return EnvironmentConfig(
        max_actions_per_level=max_actions_per_level,
        max_levels_per_game=_optional_positive_int(
            raw_data.get("max_levels_per_game"),
            key="max_levels_per_game",
        ),
        game_index=game_index,
        game_indices=game_indices,
        game_ids=game_ids,
        game_selection=game_selection,
        max_parallel_games=_optional_positive_int(
            raw_data.get("max_parallel_games"),
            key="max_parallel_games",
        ),
        max_game_retries=_non_negative_int(
            raw_data.get("max_game_retries", 0),
            key="max_game_retries",
        ),
        game_id=game_id,
        operation_mode=operation_mode,
        game_catalog_path=str(
            raw_data.get(
                "game_catalog_path",
                "src/face_of_agi/environment/local_games.json",
            )
        ),
        environments_dir=str(raw_data.get("environments_dir", "environment_files")),
        recordings_dir=str(raw_data.get("recordings_dir", "recordings")),
        enable_visualization=bool(raw_data.get("enable_visualization", False)),
        render_mode=_optional_string(raw_data.get("render_mode")),
        seed=int(raw_data.get("seed", 0)),
        save_recording=bool(raw_data.get("save_recording", False)),
        use_learned_contexts=_optional_bool(
            raw_data.get("use_learned_contexts"),
            default=True,
        ),
        experimental_memory_turn_buffer=int(
            raw_data.get("experimental_memory_turn_buffer", 2)
        ),
        agent_action_history_window=_non_negative_int(
            raw_data.get("agent_action_history_window", 8),
            key="agent_action_history_window",
        ),
        agent_updater_action_history_window=_non_negative_int(
            raw_data.get("agent_updater_action_history_window", 8),
            key="agent_updater_action_history_window",
        ),
        agent_context_history_window=_non_negative_int(
            raw_data.get("agent_context_history_window", 8),
            key="agent_context_history_window",
        ),
        animation_keyframe_pixel_threshold=_non_negative_int(
            raw_data.get("animation_keyframe_pixel_threshold", 8),
            key="animation_keyframe_pixel_threshold",
        ),
        action_suppression_zero_changed_pixel_turns=_non_negative_int(
            raw_data.get("action_suppression_zero_changed_pixel_turns", 3),
            key="action_suppression_zero_changed_pixel_turns",
        ),
        updater_stagnation_warning_zero_changed_pixel_turns=_non_negative_int(
            raw_data.get("updater_stagnation_warning_zero_changed_pixel_turns", 3),
            key="updater_stagnation_warning_zero_changed_pixel_turns",
        ),
        candidate_action_count=_positive_int(
            raw_data.get("candidate_action_count", 8),
            key="candidate_action_count",
        ),
        reward_lp_weight_start=_bounded_float(
            raw_data.get("reward_lp_weight_start", 0.8),
            key="reward_lp_weight_start",
            minimum=0.0,
            maximum=1.0,
        ),
        reward_lp_weight_end=_bounded_float(
            raw_data.get("reward_lp_weight_end", 0.2),
            key="reward_lp_weight_end",
            minimum=0.0,
            maximum=1.0,
        ),
        reward_progress_bonus=_non_negative_float(
            raw_data.get("reward_progress_bonus", 1.0),
            key="reward_progress_bonus",
        ),
        debug_keep_all_m_states=_optional_bool(
            raw_data.get("debug_keep_all_m_states"),
            default=False,
        ),
        debug_trace=_choice(
            raw_data.get("debug_trace"),
            key="debug_trace",
            default="minimal",
            allowed=("off", "minimal", "agent_decision", "verbose", "model_inputs"),
        ),
        debug_color=_choice(
            raw_data.get("debug_color"),
            key="debug_color",
            default="auto",
            allowed=("auto", "always", "never"),
        ),
        live_turn_monitor=_optional_bool(
            raw_data.get("live_turn_monitor"),
            default=False,
        ),
        models=models,
        online_lora=online_lora,
    )


def _load_model_runtime_config(value: Any) -> ModelRuntimeConfig:
    """Load optional model role backend config from YAML."""

    if value is None:
        raise ValueError("models config is required")
    if not isinstance(value, dict):
        raise ValueError("models config must be a mapping")

    _reject_removed_model_keys(value)
    return ModelRuntimeConfig(
        shared_vlm=_load_model_role_config(value.get("shared_vlm")),
        agent=_load_required_model_role_config(value, "agent"),
        change=_load_required_model_role_config(value, "change"),
        memory=_load_required_model_role_config(value, "memory"),
        world=_load_required_model_role_config(value, "world"),
        goal=_load_required_model_role_config(value, "goal"),
        interest=_load_required_model_role_config(value, "interest"),
        reward_judge=_load_required_model_role_config(value, "reward_judge"),
    )


def _load_online_lora_config(value: Any) -> OnlineLoRAConfig:
    """Load online LoRA config."""

    if value is None:
        return OnlineLoRAConfig()
    if not isinstance(value, dict):
        raise ValueError("online_lora config must be a mapping")
    learning_progress_min = _finite_float(
        value.get("learning_progress_min", -1.0),
        key="online_lora.learning_progress_min",
    )
    learning_progress_max = _finite_float(
        value.get("learning_progress_max", 1.0),
        key="online_lora.learning_progress_max",
    )
    if learning_progress_min > learning_progress_max:
        raise ValueError(
            "online_lora.learning_progress_min must be less than or equal to "
            "online_lora.learning_progress_max"
        )
    return OnlineLoRAConfig(
        enabled=_optional_bool(value.get("enabled"), default=True),
        base_model=str(value.get("base_model", "")),
        update_interval_turns=_positive_int(
            value.get("update_interval_turns", 4),
            key="online_lora.update_interval_turns",
        ),
        min_new_samples_per_update=_optional_positive_int(
            value.get("min_new_samples_per_update"),
            key="online_lora.min_new_samples_per_update",
        ),
        adapter_root=str(value.get("adapter_root", "runs/lora")),
        world_adapter_name=str(value.get("world_adapter_name", "world-lora")),
        interest_adapter_name=str(
            value.get("interest_adapter_name", "interest-lora")
        ),
        agent_adapter_name=str(value.get("agent_adapter_name", "agent-lora")),
        max_train_samples=_positive_int(
            value.get("max_train_samples", 16),
            key="online_lora.max_train_samples",
        ),
        held_out_recent_samples=_positive_int(
            value.get("held_out_recent_samples", 8),
            key="online_lora.held_out_recent_samples",
        ),
        train_batch_size=_positive_int(
            value.get("train_batch_size", 1),
            key="online_lora.train_batch_size",
        ),
        train_epochs=_positive_int(
            value.get("train_epochs", 1),
            key="online_lora.train_epochs",
        ),
        max_update_steps=_optional_positive_int(
            value.get("max_update_steps"),
            key="online_lora.max_update_steps",
        ),
        grpo_num_generations=_positive_int(
            value.get("grpo_num_generations", 4),
            key="online_lora.grpo_num_generations",
        ),
        max_completion_tokens=_positive_int(
            value.get("max_completion_tokens", 512),
            key="online_lora.max_completion_tokens",
        ),
        learning_rate=_positive_float(
            value.get("learning_rate", 1e-5),
            key="online_lora.learning_rate",
        ),
        learning_progress_min=learning_progress_min,
        learning_progress_max=learning_progress_max,
    )


def _load_required_model_role_config(
    value: dict[str, Any],
    role_name: str,
) -> ModelRoleConfig:
    """Load one required model role config."""

    if role_name not in value:
        raise ValueError(f"models.{role_name} config is required")
    config = _load_model_role_config(value[role_name])
    if config.backend is None or config.backend == "":
        raise ValueError(f"models.{role_name}.backend is required")
    return config


def _reject_removed_model_keys(value: dict[str, Any]) -> None:
    removed = sorted(set(value) & {"historizer", "updater"})
    if removed:
        names = ", ".join(f"models.{key}" for key in removed)
        raise ValueError(f"{names} config has been replaced by v1 roles")


def _load_model_role_config(value: Any) -> ModelRoleConfig:
    """Load one role config from a YAML mapping."""

    if value is None:
        return ModelRoleConfig()
    if not isinstance(value, dict):
        raise ValueError("model role config must be a mapping")

    _reject_removed_model_role_keys(value)
    known_keys = {"backend", "model", "max_tool_calls", "repair_attempts"}
    options = dict(value.get("options") or {})
    _reject_removed_model_role_keys(options)
    for key, item in value.items():
        if key not in known_keys and key != "options":
            options[key] = item

    return ModelRoleConfig(
        backend=_optional_string(value.get("backend")),
        model=_optional_string(value.get("model")),
        max_tool_calls=(
            int(value["max_tool_calls"])
            if value.get("max_tool_calls") is not None
            else None
        ),
        repair_attempts=(
            int(value["repair_attempts"])
            if value.get("repair_attempts") is not None
            else None
        ),
        options=options,
    )


def _reject_removed_model_role_keys(value: dict[str, Any]) -> None:
    if "input_image_crop_box_normalized" in value:
        raise ValueError(
            "input_image_crop_box_normalized has been removed; use "
            "input_image_crop_arc_grid_edges"
        )


def _read_yaml(path: str | Path) -> dict[str, Any]:
    """Read one YAML mapping from disk."""

    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle) or {}

    if not isinstance(loaded, dict):
        raise ValueError(f"environment config must be a mapping: {config_path}")

    missing_keys = {"max_actions_per_level"} - loaded.keys()
    if missing_keys:
        missing = ", ".join(sorted(missing_keys))
        raise ValueError(f"environment config is missing required keys: {missing}")

    if "max_actions_per_game" in loaded:
        raise ValueError(
            "max_actions_per_game has been removed; use max_actions_per_level "
            "for the per-level action budget"
        )
    return loaded


def _load_game_selection(
    value: dict[str, Any],
) -> tuple[int | None, tuple[int, ...], tuple[str, ...], GameSelectionMode | None]:
    """Return exactly one configured runtime game selector."""

    has_single = value.get("game_index") is not None
    game_indices = _optional_game_indices(value.get("game_indices"))
    game_ids = _optional_game_ids(value.get("game_ids"))
    game_selection = _optional_game_selection(value.get("game_selection"))
    selected_count = sum(
        (
            1 if has_single else 0,
            1 if game_indices else 0,
            1 if game_ids else 0,
            1 if game_selection is not None else 0,
        )
    )
    if selected_count > 1:
        raise ValueError(
            "configure exactly one of game_index, game_indices, game_ids, "
            "or game_selection"
        )
    if selected_count == 0:
        raise ValueError(
            "environment config requires game_index, game_indices, game_ids, "
            "or game_selection"
        )
    return (
        _non_negative_int(value["game_index"], key="game_index")
        if has_single
        else None,
        game_indices,
        game_ids,
        game_selection,
    )


def _optional_game_indices(value: Any) -> tuple[int, ...]:
    """Normalize an optional list of selected game catalog indices."""

    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError("game_indices must be a list of non-negative integers")
    if not value:
        raise ValueError("game_indices must not be empty")

    indices = tuple(_non_negative_int(item, key="game_indices") for item in value)
    if len(set(indices)) != len(indices):
        raise ValueError("game_indices must not contain duplicates")
    return indices


def _optional_game_ids(value: Any) -> tuple[str, ...]:
    """Normalize an optional list of explicit ARC game ids."""

    if value is None:
        return ()
    if not isinstance(value, (list, tuple)):
        raise ValueError("game_ids must be a list of non-empty strings")
    if not value:
        raise ValueError("game_ids must not be empty")

    game_ids = tuple(str(item).strip() for item in value)
    if any(not game_id for game_id in game_ids):
        raise ValueError("game_ids must contain non-empty strings")
    if len(set(game_ids)) != len(game_ids):
        raise ValueError("game_ids must not contain duplicates")
    return game_ids


def _optional_game_selection(value: Any) -> GameSelectionMode | None:
    """Normalize the optional named runtime game selector."""

    if value is None:
        return None
    parsed = str(value).strip()
    if parsed != "all_available":
        raise ValueError("game_selection must be all_available")
    return "all_available"


def _optional_string(value: Any) -> str | None:
    """Normalize optional scalar config values."""

    if value is None:
        return None
    return str(value)


def _optional_bool(value: Any, *, default: bool = False) -> bool:
    """Normalize optional boolean config values."""

    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
    raise ValueError(f"expected boolean config value, got {value!r}")


def _non_negative_int(value: Any, *, key: str) -> int:
    """Normalize one non-negative integer config value."""

    parsed = int(value)
    if parsed < 0:
        raise ValueError(f"{key} must be non-negative")
    return parsed


def _optional_positive_int(value: Any, *, key: str) -> int | None:
    """Normalize one optional positive integer config value."""

    if value is None:
        return None
    parsed = int(value)
    if parsed < 1:
        raise ValueError(f"{key} must be at least 1")
    return parsed


def _positive_int(value: Any, *, key: str) -> int:
    """Normalize one required positive integer config value."""

    parsed = int(value)
    if parsed < 1:
        raise ValueError(f"{key} must be at least 1")
    return parsed


def _bounded_float(
    value: Any,
    *,
    key: str,
    minimum: float,
    maximum: float,
) -> float:
    """Normalize one float in an inclusive range."""

    parsed = float(value)
    if not minimum <= parsed <= maximum:
        raise ValueError(f"{key} must be within {minimum}..{maximum}")
    return parsed


def _non_negative_float(value: Any, *, key: str) -> float:
    """Normalize one non-negative float config value."""

    parsed = float(value)
    if parsed < 0:
        raise ValueError(f"{key} must be non-negative")
    return parsed


def _positive_float(value: Any, *, key: str) -> float:
    """Normalize one positive float config value."""

    parsed = float(value)
    if parsed <= 0:
        raise ValueError(f"{key} must be positive")
    return parsed


def _finite_float(value: Any, *, key: str) -> float:
    """Normalize one finite float config value."""

    from math import isfinite

    parsed = float(value)
    if not isfinite(parsed):
        raise ValueError(f"{key} must be finite")
    return parsed


def _choice(
    value: Any,
    *,
    key: str,
    default: str,
    allowed: tuple[str, ...],
) -> Any:
    """Normalize one string enum config value."""

    if value is None:
        parsed = default
    elif isinstance(value, bool) and "off" in allowed:
        parsed = "off" if value is False else "on"
    else:
        parsed = str(value).strip()
    if parsed not in allowed:
        options = ", ".join(allowed)
        raise ValueError(f"{key} must be one of: {options}")
    return parsed


def load_game_catalog(path: str | Path) -> dict[str, str]:
    """Load the locally stored game catalog written by `--list-games`."""

    catalog_path = Path(path)
    with catalog_path.open("r", encoding="utf-8") as handle:
        loaded = json.load(handle)

    if not isinstance(loaded, dict):
        raise ValueError(f"game catalog must be a JSON object: {catalog_path}")

    return {str(key): str(value) for key, value in loaded.items()}


def write_game_catalog(path: str | Path, games: dict[str, str]) -> None:
    """Write the indexed game catalog to a local JSON file."""

    catalog_path = Path(path)
    catalog_path.parent.mkdir(parents=True, exist_ok=True)
    with catalog_path.open("w", encoding="utf-8") as handle:
        json.dump(games, handle, indent=2, sort_keys=True)
        handle.write("\n")
